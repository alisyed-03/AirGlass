/* Exercise the real accepted mirroring socket, including fragmented receive timeouts. */
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "raop.h"
#include "raop_ntp.h"
#include "raop_rtp_mirror.h"
#include "logger.h"
static volatile LONG ack_seen, receive_errors, timeout_seen;
static void observe(void *cls, int level, const char *message) {
    if (strstr(message, "immediate TCP acknowledgements enabled")) InterlockedExchange(&ack_seen, 1);
    if (strstr(message, "retaining partial")) InterlockedExchange(&timeout_seen, 1);
    if (level <= LOGGER_ERR) { InterlockedIncrement(&receive_errors); printf("Unexpected error: %s\n", message); }
}
static void require(int condition, const char *message) { if (!condition) { printf("FAIL: %s\n", message); exit(1); } }
int main(void) {
    WSADATA data; require(WSAStartup(MAKEWORD(2,2), &data) == 0, "Winsock startup");
    logger_t *logger=logger_init(); logger_set_level(logger, LOGGER_DEBUG); logger_set_callback(logger, observe, NULL);
    raop_callbacks_t callbacks; memset(&callbacks, 0, sizeof(callbacks));
    const char *remote="127.0.0.1"; unsigned char key[16]={0};
    for (int payload_test=0; payload_test<2; ++payload_test) {
        InterlockedExchange(&ack_seen,0); InterlockedExchange(&receive_errors,0); InterlockedExchange(&timeout_seen,0);
        timing_protocol_t protocol=TP_NONE;
        raop_ntp_t *ntp=raop_ntp_init(logger,&callbacks,remote,4,0,&protocol);
        require(ntp != NULL, "NTP context");
        raop_rtp_mirror_t *mirror=raop_rtp_mirror_init(logger,&callbacks,ntp,remote,4,key);
        require(mirror != NULL, "Mirror context");
        unsigned short port=0; raop_rtp_mirror_start(mirror,&port,0); require(port != 0, "Mirror port");
        SOCKET client=socket(AF_INET,SOCK_STREAM,0);
        struct sockaddr_in address; memset(&address,0,sizeof(address)); address.sin_family=AF_INET;
        address.sin_addr.s_addr=htonl(INADDR_LOOPBACK); address.sin_port=htons(port);
        require(connect(client,(struct sockaddr*)&address,sizeof(address)) == 0,"Connect mirror stream");
        unsigned char packet[128]={0}; packet[0]=8; packet[4]=2;
        if (payload_test) { require(send(client,(const char*)packet,128,0)==128,"Send complete header"); require(send(client,"a",1,0)==1,"Send partial payload"); }
        else { require(send(client,(const char*)packet,37,0)==37,"Send partial header"); }
        for (int wait=0; wait<100 && !InterlockedCompareExchange(&timeout_seen,0,0); ++wait) Sleep(10);
        require(InterlockedCompareExchange(&ack_seen,0,0)==1,"Actual mirror connection enabled immediate ACKs");
        require(InterlockedCompareExchange(&receive_errors,0,0)==0,"Partial record timeout must not end the connection");
        require(InterlockedCompareExchange(&timeout_seen,0,0)==1,"The real receive timeout recovery branch was exercised");
        raop_rtp_mirror_stop(mirror); closesocket(client);
        raop_rtp_mirror_destroy(mirror); raop_ntp_destroy(ntp);
        printf("PASS: Real mirror socket ACK tuning and %s timeout recovery\n", payload_test ? "payload" : "header");
    }
    logger_destroy(logger); WSACleanup(); return 0;
}
