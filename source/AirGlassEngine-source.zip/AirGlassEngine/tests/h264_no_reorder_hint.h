/* Test fixture: retain valid High-profile I/P pictures but omit optional VUI
 * reordering hints, as a live sender is permitted to do. GPL-3.0-or-later. */
typedef struct {guint8 *data;guint bit,size;} test_bits;
static guint tb_read(test_bits *b,guint n) {
    guint v=0;while(n--){if(b->bit>=b->size*8)g_error("Truncated SPS");v=(v<<1)|((b->data[b->bit/8]>>(7-b->bit%8))&1);b->bit++;}return v;
}
static guint tb_ue(test_bits *b) {guint z=0;while(!tb_read(b,1)){if(++z>30)g_error("Invalid SPS code");}return ((1u<<z)-1)+tb_read(b,z);}
static gint tb_se(test_bits *b) {guint v=tb_ue(b);return v&1 ? (v+1)/2 : -(gint)(v/2);}
static guint test_start(const guint8 *d,guint size,guint at) {
    for(guint i=at;i+3<size;i++)if(!d[i]&&!d[i+1]&&(d[i+2]==1 || (!d[i+2]&&d[i+3]==1)))return i;return size;
}
static GstBuffer *test_omit_reorder_hint(GstBuffer *input) {
    GstMapInfo map;gst_buffer_map(input,&map,GST_MAP_READ);
    GByteArray *out=g_byte_array_new();guint cursor=0;
    while(cursor<map.size) {
        guint start=test_start(map.data,map.size,cursor);
        if(start==map.size){g_byte_array_append(out,map.data+cursor,map.size-cursor);break;}
        guint prefix=map.data[start+2]==1 ? 3 : 4;
        guint nal=start+prefix,end=test_start(map.data,map.size,nal+1);
        g_byte_array_append(out,map.data+cursor,nal-cursor);
        if((map.data[nal]&31)!=7)g_byte_array_append(out,map.data+nal,end-nal);
        else {
            g_byte_array_append(out,map.data+nal,1);
            GByteArray *rbsp=g_byte_array_new();guint zeros=0;
            for(guint i=nal+1;i<end;i++) {
                guint8 v=map.data[i];if(zeros>=2 && v==3){zeros=0;continue;}
                g_byte_array_append(rbsp,&v,1);zeros=v==0 ? zeros+1 : 0;
            }
            test_bits b={rbsp->data,0,rbsp->len};guint profile=tb_read(&b,8);
            tb_read(&b,8);tb_read(&b,8);tb_ue(&b);
            if(profile==100 || profile==110 || profile==122 || profile==244 || profile==44 || profile==83 || profile==86 || profile==118 || profile==128) {
                guint chroma=tb_ue(&b);if(chroma==3)tb_read(&b,1);tb_ue(&b);tb_ue(&b);tb_read(&b,1);
                if(tb_read(&b,1))for(guint i=0;i<(chroma==3 ? 12u : 8u);i++)if(tb_read(&b,1)) {
                    gint last=8,next=8;for(guint j=0;j<(i<6 ? 16u : 64u);j++){if(next)next=(last+tb_se(&b)+256)%256;last=next ? next : last;}
                }
            }
            tb_ue(&b);guint poc=tb_ue(&b);
            if(poc==0)tb_ue(&b);
            else if(poc==1){tb_read(&b,1);tb_se(&b);tb_se(&b);guint n=tb_ue(&b);while(n--)tb_se(&b);}
            tb_ue(&b);tb_read(&b,1);tb_ue(&b);tb_ue(&b);
            if(!tb_read(&b,1))tb_read(&b,1);tb_read(&b,1);
            if(tb_read(&b,1))for(guint i=0;i<4;i++)tb_ue(&b);
            guint pos=b.bit; /* vui_parameters_present_flag */
            rbsp->data[1]&=~0x10; /* constraint_set3_flag must not infer zero reorder */
            for(guint bit=pos;bit<rbsp->len*8;bit++)rbsp->data[bit/8]&=~(1u<<(7-bit%8));
            rbsp->data[(pos+1)/8]|=1u<<(7-(pos+1)%8); /* rbsp_stop_one_bit */
            zeros=0;guint len=(pos+2+7)/8;
            for(guint i=0;i<len;i++) {
                guint8 v=rbsp->data[i];if(zeros>=2 && v<=3){guint8 ep=3;g_byte_array_append(out,&ep,1);zeros=0;}
                g_byte_array_append(out,&v,1);zeros=v==0 ? zeros+1 : 0;
            }
            g_byte_array_unref(rbsp);
        }
        cursor=end;
    }
    gst_buffer_unmap(input,&map);GstBuffer *result=gst_buffer_new_allocate(NULL,out->len,NULL);
    gst_buffer_fill(result,0,out->data,out->len);g_byte_array_unref(out);return result;
}
