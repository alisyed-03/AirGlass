/* Actual AirGlass renderer integration, including hardware presentation.
 * Test-only OpenH264 encoder is not part of the distributed app. GPL-3.0-or-later. */
#include <gst/gst.h>
#include <gst/app/gstappsink.h>
#include "video_renderer.h"
#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <mmsystem.h>
#include "h264_no_reorder_hint.h"

static guint frame_count = 100, width = 1280, height = 720, frame_rate = 30;
static const char *decoder_mode = "Auto";
static gboolean hevc = FALSE;
static guint nv_tuning, gpu_frames;
static gboolean expect_fallback;
static guint fallback_messages;
static const char *expected_decoder;
static guint expected_decoder_messages;
static guint errors, metrics, gpu_limits, hardware, unmatched;
static double best_present, best_decode, best_pacing, last_fps;
static void log_line(void *cls, int level, const char *line) {
    printf("%s\n", line);
    if (expected_decoder && strstr(line, "AirGlass decoder:") && strstr(line, expected_decoder)) expected_decoder_messages++;
    if (level == LOGGER_ERR) errors++;
    if (strstr(line, "AirGlass GPU queue: maximum=1")) gpu_limits++;
    if (strstr(line, "AirGlass decoder: d3d11h264dec (hardware)") || strstr(line, "AirGlass decoder: d3d11h265dec (hardware)")) hardware++;
    if (strstr(line, "AirGlass decoder: nvh264dec (hardware)") || strstr(line, "AirGlass decoder: nvh265dec (hardware)")) hardware++;
    if (strstr(line, "AirGlass NVDEC:") && strstr(line, "max-display-delay=0")) nv_tuning++;
    if (strstr(line, "AirGlass decoded format: video/x-raw(memory:D3D11Memory)")) gpu_frames++;
    if (strstr(line, "automatic fallback active")) fallback_messages++;
    if (strstr(line, "AirGlass metrics:")) {
        double fps, decode, processing, present, pacing;
        if (sscanf(line, "AirGlass metrics: rendered-fps=%lf decode-ms=%lf processing-ms=%lf present-ms=%lf pacing-ms=%lf",
                   &fps, &decode, &processing, &present, &pacing) != 5) g_error("Invalid timing log");
        metrics++; last_fps = fps;
        if (decode > 0 && decode < best_decode) best_decode = decode;
        if (present > 0 && present < best_present) best_present = present;
        if (pacing >= 0 && pacing < best_pacing) best_pacing = pacing;
        if (!strstr(line, "unmatched=0")) unmatched++;
    }
}
static GPtrArray *make_stream(void) {
    GError *error = NULL;
    gboolean nv_encoder = !strcmp(decoder_mode, "Nvidia") || g_strcmp0(g_getenv("AIRGLASS_TEST_NV_FIXTURE"), "1") == 0;
    const char *encoder_path = nv_encoder
        ? (hevc ? "nvd3d11h265enc bitrate=3000 gop-size=30 bframes=0 ! h265parse ! video/x-h265,stream-format=byte-stream,alignment=au,profile=main"
                : "nvd3d11h264enc bitrate=3000 gop-size=30 bframes=0 ! h264parse ! video/x-h264,stream-format=byte-stream,alignment=au,profile=high")
        : "openh264enc complexity=low bitrate=3000000 gop-size=30 ! h264parse ! video/x-h264,stream-format=byte-stream,alignment=au,profile=baseline";
    gchar *description = g_strdup_printf(
        "videotestsrc num-buffers=%u pattern=ball ! video/x-raw,format=I420,width=%u,height=%u,framerate=%u/1 ! "
        "videoconvert ! video/x-raw,format=%s ! %s ! appsink name=encoded sync=false",
        frame_count, width, height, frame_rate, nv_encoder ? "NV12" : "I420", encoder_path);
    GstElement *encoder = gst_parse_launch(description, &error);
    g_free(description);
    if (error || !encoder) g_error("Encoder unavailable: %s", error ? error->message : "null");
    GstElement *sink = gst_bin_get_by_name(GST_BIN(encoder), "encoded");
    GPtrArray *frames = g_ptr_array_new_with_free_func((GDestroyNotify) gst_buffer_unref);
    gst_element_set_state(encoder, GST_STATE_PLAYING);
    for (guint i = 0; i < frame_count; i++) {
        GstSample *sample = gst_app_sink_try_pull_sample(GST_APP_SINK(sink), 5 * GST_SECOND);
        if (!sample) g_error("Encoder returned too few access units");
        GstBuffer *encoded=gst_sample_get_buffer(sample);
        g_ptr_array_add(frames, g_getenv("AIRGLASS_TEST_NO_REORDER_HINT") ? test_omit_reorder_hint(encoded) : gst_buffer_copy_deep(encoded));
        gst_sample_unref(sample);
    }
    gst_element_set_state(encoder, GST_STATE_NULL);
    gst_object_unref(sink); gst_object_unref(encoder);
    return frames;
}
static void run(GPtrArray *frames, gboolean paced, gboolean software) {
    errors = metrics = gpu_limits = hardware = unmatched = 0;
    nv_tuning = gpu_frames = 0;
    fallback_messages = 0;
    expected_decoder_messages = 0;
    best_decode = best_present = best_pacing = 100000;
    last_fps = 0;
    g_setenv("AIRGLASS_LOW_LATENCY", "1", TRUE);
    g_setenv("AIRGLASS_GPU_RENDERER", software ? "0" : "1", TRUE);
    g_setenv("AIRGLASS_DECODER", decoder_mode, TRUE);
    g_setenv("AIRGLASS_FRAME_PACING", paced ? "1" : "0", TRUE);
    gchar *fps_text = g_strdup_printf("%u", frame_rate);
    g_setenv("AIRGLASS_FPS", fps_text, TRUE); g_free(fps_text);
    logger_t *log = logger_init(); logger_set_callback(log, log_line, NULL);
    logger_set_level(log, LOGGER_INFO);
    videoflip_t flip[2] = {NONE, NONE};
    video_renderer_init(log, "AirGlass renderer verification", flip, "h264parse", software ? "avdec_h264" : "decodebin",
        "videoconvert", "d3d11videosink", " processing-deadline=0", false, false, hevc, 0, NULL);
    video_renderer_start();
    if (video_renderer_choose_codec(hevc)) g_error("Cannot start actual renderer");
    guint64 begin = gst_util_get_timestamp();
    guint64 capture_origin = (guint64) g_get_real_time() * 1000;
    GstClock *clock = gst_system_clock_obtain();
    for (guint i = 0; i < frames->len; i++) {
        guint64 target = begin + gst_util_uint64_scale(i, GST_SECOND, frame_rate);
        GstClockID wait = gst_clock_new_single_shot_id(clock, target);
        gst_clock_id_wait(wait, NULL); gst_clock_id_unref(wait);
        GstMapInfo map;
        gst_buffer_map(g_ptr_array_index(frames, i), &map, GST_MAP_READ);
        int bytes = map.size, nals = 0;
        guint64 capture = capture_origin + gst_util_uint64_scale(i, GST_SECOND, frame_rate);
        video_renderer_render_buffer(map.data, &bytes, &nals, &capture);
        gst_buffer_unmap(g_ptr_array_index(frames, i), &map);
    }
    g_usleep(150000);
    video_renderer_stop(); video_renderer_destroy(); logger_destroy(log); gst_object_unref(clock);
    if (errors || !metrics || !gpu_limits || unmatched || last_fps < frame_rate * 0.5 || best_present >= 100000)
        g_error("Actual renderer failed: errors=%u metrics=%u gpu=%u unmatched=%u fps=%.1f present=%.2f",
                errors, metrics, gpu_limits, unmatched, last_fps, best_present);
    if (!software && !hardware && (!expected_decoder || !strstr(expected_decoder,"avdec"))) g_error("Hardware path was not exercised");
    if (!software && expected_decoder && !expected_decoder_messages) g_error("Expected decoder %s was not used",expected_decoder);
    if (!strcmp(decoder_mode,"Direct3D11") && !g_getenv("AIRGLASS_TEST_NV_FIXTURE") && GetModuleHandleA("libgstcuda-1.0-0.dll"))
        g_error("Direct3D11 unexpectedly loaded the NVIDIA CUDA runtime");
    if (!strcmp(decoder_mode, "Nvidia") && !expect_fallback && (!nv_tuning || !gpu_frames)) g_error("NVDEC tuning or GPU memory path not exercised");
    if (expect_fallback && (!fallback_messages || nv_tuning || !gpu_frames)) g_error("Missing NVIDIA runtime did not fall back cleanly");
    if (paced && (best_pacing < 4 || best_pacing > 1000.0 / frame_rate + 0.01)) g_error("Adaptive budget out of bounds");
    printf("PASS: %ux%u@%u %s %s actual %s renderer, %s, decode=%.2f ms input-to-Present=%.2f ms pacing=%.2f ms GPU queue=1\n",
           width, height, frame_rate, hevc ? "HEVC" : "H264", decoder_mode, software ? "software" : "hardware", paced ? "adaptive pacing" : "immediate", best_decode, best_present, best_pacing);
}
typedef struct {GPtrArray *frames;gint stop;} close_producer;
static gpointer produce_until_stopped(gpointer data) {
    close_producer *p=data;guint i=0;guint64 origin=(guint64)g_get_real_time()*1000;
    while(!g_atomic_int_get(&p->stop)) {
        GstMapInfo map;gst_buffer_map(g_ptr_array_index(p->frames,i%p->frames->len),&map,GST_MAP_READ);
        int bytes=map.size,nals=0;guint64 capture=origin+gst_util_uint64_scale(i++,GST_SECOND,frame_rate);
        video_renderer_render_buffer(map.data,&bytes,&nals,&capture);
        gst_buffer_unmap(g_ptr_array_index(p->frames,(i-1)%p->frames->len),&map);
    }
    return NULL;
}
static void close_under_load(GPtrArray *frames) {
    g_log_set_always_fatal(G_LOG_FATAL_MASK | G_LOG_LEVEL_CRITICAL);
    for(guint i=0;i<5;i++) {
        logger_t *log=logger_init();logger_set_callback(log,log_line,NULL);logger_set_level(log,LOGGER_INFO);
        videoflip_t flip[2]={NONE,NONE};
        g_setenv("AIRGLASS_LOW_LATENCY","1",TRUE);g_setenv("AIRGLASS_FRAME_PACING","1",TRUE);
        video_renderer_init(log,"AirGlass close verification",flip,"h264parse","decodebin","videoconvert","d3d11videosink"," processing-deadline=0",false,false,false,0,NULL);
        video_renderer_start();if(video_renderer_choose_codec(false))g_error("Close-test codec initialization failed");
        close_producer producer={frames,0};GThread *thread=g_thread_new("mirror-producer",produce_until_stopped,&producer);
        g_usleep(70000);g_atomic_int_set(&producer.stop,1);
        video_renderer_stop();g_thread_join(thread);video_renderer_destroy();logger_destroy(log);
        printf("PASS: close-under-load cycle %u flushes pushes and joins the producer before renderer destruction\n",i+1);
    }
}
int main(int argc, char **argv) {
    setvbuf(stdout, NULL, _IONBF, 0); gst_init(&argc, &argv);
    if (argc >= 4) {
        width = atoi(argv[1]); height = atoi(argv[2]); frame_rate = atoi(argv[3]);
        if (!width || !height || (frame_rate != 15 && frame_rate != 30 && frame_rate != 60)) g_error("Invalid test parameters");
        frame_count = frame_rate * 3 + 10;
    }
    if (argc >= 5) decoder_mode = argv[4];
    if (argc >= 6) hevc = !strcmp(argv[5], "H265");
    if (argc >= 7) expected_decoder = argv[6];
    expect_fallback = g_strcmp0(g_getenv("AIRGLASS_TEST_EXPECT_FALLBACK"), "1") == 0;
    GPtrArray *frames = make_stream();
    /* Test-only capability emulation. Production never reads these variables. */
    const gchar *disable = g_getenv("AIRGLASS_TEST_HIDE_DECODERS");
    if (disable) {
        GstPlugin *plugin=gst_plugin_load_by_name("d3d11");
        if (plugin) gst_object_unref(plugin);
        plugin=gst_plugin_load_by_name("nvcodec");
        if (plugin) gst_object_unref(plugin);
        GList *features = gst_element_factory_list_get_elements(GST_ELEMENT_FACTORY_TYPE_DECODER, GST_RANK_NONE);
        for (GList *p=features;p;p=p->next) {
            const gchar *name=GST_OBJECT_NAME(p->data);
            if ((!strcmp(disable,"all-hardware") && !g_str_has_prefix(name,"avdec_") && (strstr(name,"h264") || strstr(name,"h265"))) ||
                (!strcmp(disable,"nvidia") && g_str_has_prefix(name,"nv")) ||
                (!strcmp(disable,"direct3d") && g_str_has_prefix(name,"d3d")))
                gst_registry_remove_feature(gst_registry_get(),GST_PLUGIN_FEATURE(p->data));
        }
        gst_plugin_feature_list_free(features);
    }
    run(frames, FALSE, FALSE); run(frames, TRUE, FALSE);
    if (strcmp(decoder_mode, "Nvidia")) run(frames, TRUE, TRUE);
    if(g_getenv("AIRGLASS_TEST_CLOSE_UNDER_LOAD"))close_under_load(frames);
    g_ptr_array_unref(frames); return 0;
}
