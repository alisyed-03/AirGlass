/**
 * RPiPlay - An open-source AirPlay mirroring server for Raspberry Pi
 * Copyright (C) 2019 Florian Draschbacher
 * Modified for:
 * UxPlay - An open-source AirPlay mirroring server
 * Copyright (C) 2021-24 F. Duncanh
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

#include <gst/gst.h>
#include <gst/app/gstappsrc.h>
#include "video_renderer.h"
#include "airglass_pacing.h"
#include "airglass_gpu.h"
#include "airglass_decoder.h"
#ifdef _WIN32
#include <mmsystem.h>
static gboolean airglass_precise_timer=FALSE;
#endif

#define SECOND_IN_NSECS 1000000000UL
#define SECOND_IN_MICROSECS 1000000
#ifdef X_DISPLAY_FIX
#include <gst/video/navigation.h>
#include "x_display_fix.h"
static bool fullscreen = false;
static bool alt_keypress = false;
static unsigned char X11_search_attempts;
#endif

static GstClockTime gst_video_pipeline_base_time = GST_CLOCK_TIME_NONE;
static logger_t *logger = NULL;
static unsigned short width, height, width_source, height_source;  /* not currently used */
static bool first_packet = false;
static bool sync = false;
static bool auto_videosink = true;
static bool hls_video = false;
#ifdef X_DISPLAY_FIX
static bool use_x11 = false;
#endif
static bool logger_debug = false;
static bool video_terminate = false;
static gint64 hls_requested_start_position = 0;
static gint64 hls_seek_start = 0;
static gint64 hls_seek_end = 0;
static gint64 hls_duration;
static gboolean hls_seek_enabled;
static gboolean hls_playing;
static gboolean hls_buffer_empty;
static gboolean hls_buffer_full;


typedef enum {
  //GST_PLAY_FLAG_VIDEO         = (1 << 0),
  //GST_PLAY_FLAG_AUDIO         = (1 << 1),
  //GST_PLAY_FLAG_TEXT          = (1 << 2),
  //GST_PLAY_FLAG_VIS           = (1 << 3),
  //GST_PLAY_FLAG_SOFT_VOLUME   = (1 << 4),
  //GST_PLAY_FLAG_NATIVE_AUDIO  = (1 << 5),
  //GST_PLAY_FLAG_NATIVE_VIDEO  = (1 << 6),
  GST_PLAY_FLAG_DOWNLOAD      = (1 << 7),
  GST_PLAY_FLAG_BUFFERING     = (1 << 8),
  //GST_PLAY_FLAG_DEINTERLACE   = (1 << 9),
  //GST_PLAY_FLAG_SOFT_COLORBALANCE = (1 << 10),
  //GST_PLAY_FLAG_FORCE_FILTERS = (1 << 11),
  //GST_PLAY_FLAG_FORCE_SW_DECODERS = (1 << 12),
} GstPlayFlags;

#define NCODECS  2   /* renderers for h264 and h265 */
#define AIRGLASS_RECEIPTS 256

typedef struct {
    guint64 input_pts, scheduled_pts, capture, arrival, decoded, sequence;
} airglass_receipt_t;

struct video_renderer_s {
    GstElement *appsrc, *pipeline;
    GstBus *bus;
    const char *codec;
    bool autovideo;
    int id;
    gboolean terminate;
    gboolean airglass_low_latency;
    gboolean airglass_frame_pacing;
    guint64 airglass_frame_budget;
    airglass_pacing_t airglass_pacing;
    GMutex airglass_receipt_lock;
    guint64 airglass_receipt_index;
    airglass_receipt_t airglass_receipts[AIRGLASS_RECEIPTS];
    airglass_receipt_t airglass_pending_present;
    gpointer airglass_gpu_device;
    guint64 airglass_report_time, airglass_frames, airglass_delay_total;
    guint64 airglass_decode_total, airglass_decode_samples, airglass_present_total;
    guint64 airglass_present_samples, airglass_last_present_seq, airglass_unmatched;
    guint64 airglass_previous_rendered, airglass_previous_dropped;
    gint64 duration;
    gint buffering_level;
#ifdef  X_DISPLAY_FIX
    bool use_x11;
    const char * server_name;
    X11_Window_t * gst_window;
#endif
};

/* Exact PTS association avoids guessing latency from an unrelated earlier frame. */
static airglass_receipt_t *airglass_find_receipt(video_renderer_t *r, guint64 pts, gboolean scheduled) {
    airglass_receipt_t *found = NULL;
    if (!GST_CLOCK_TIME_IS_VALID(pts)) return NULL;
    for (guint i = 0; i < AIRGLASS_RECEIPTS; i++) {
        airglass_receipt_t *item = &r->airglass_receipts[i];
        if (item->sequence && (scheduled ? item->scheduled_pts : item->input_pts) == pts &&
            (!found || item->sequence > found->sequence)) found = item;
    }
    return found;
}

static GstPadProbeReturn airglass_decoded_frame(GstPad *pad, GstPadProbeInfo *info, gpointer user_data) {
    video_renderer_t *r = user_data;
    if (GST_PAD_PROBE_INFO_TYPE(info) & GST_PAD_PROBE_TYPE_EVENT_DOWNSTREAM) {
        GstEvent *event = GST_PAD_PROBE_INFO_EVENT(info);
        if (GST_EVENT_TYPE(event) == GST_EVENT_CAPS) {
            GstCaps *caps; gst_event_parse_caps(event, &caps);
            gchar *description = gst_caps_to_string(caps);
            logger_log(logger, LOGGER_INFO, "AirGlass decoded format: %s", description);
            g_free(description);
        }
        return GST_PAD_PROBE_OK;
    }
    GstBuffer *buffer = GST_PAD_PROBE_INFO_BUFFER(info);
    if (!buffer || !r->airglass_low_latency) return GST_PAD_PROBE_OK;
    guint64 now = gst_element_get_current_running_time(r->pipeline);
    if (!GST_CLOCK_TIME_IS_VALID(now)) return GST_PAD_PROBE_OK;
    g_mutex_lock(&r->airglass_receipt_lock);
    airglass_receipt_t *item = airglass_find_receipt(r, GST_BUFFER_PTS(buffer), FALSE);
    guint64 target = now;
    if (item) {
        item->decoded = now;
        if (now >= item->arrival) {
            r->airglass_decode_total += now - item->arrival;
            r->airglass_decode_samples++;
        }
        if (r->airglass_frame_pacing)
            target = airglass_presentation_time(&r->airglass_pacing, item->capture, now, r->airglass_frame_budget);
        else target = item->input_pts;
        item->scheduled_pts = target;
    } else r->airglass_unmatched++;
    g_mutex_unlock(&r->airglass_receipt_lock);
    if (r->airglass_frame_pacing) {
        buffer = gst_buffer_make_writable(buffer);
        GST_PAD_PROBE_INFO_DATA(info) = buffer;
        GST_BUFFER_PTS(buffer) = target;
    }
    return GST_PAD_PROBE_OK;
}

static void airglass_present(GstElement *sink, GstObject *device, gpointer target, gpointer user_data) {
    video_renderer_t *r = user_data;
    if (!r->airglass_low_latency) return;
    guint64 now = gst_element_get_current_running_time(r->pipeline);
    g_mutex_lock(&r->airglass_receipt_lock);
    gboolean configure = r->airglass_gpu_device != device;
    r->airglass_gpu_device = device;
    airglass_receipt_t *item = &r->airglass_pending_present;
    if (item->sequence && item->sequence != r->airglass_last_present_seq &&
        GST_CLOCK_TIME_IS_VALID(now) && now >= item->arrival) {
        r->airglass_present_total += now - item->arrival;
        r->airglass_present_samples++;
        r->airglass_last_present_seq = item->sequence;
    }
    g_mutex_unlock(&r->airglass_receipt_lock);
#ifdef _WIN32
    if (configure) {
        guint previous = 0;
        if (airglass_limit_gpu_queue(device, &previous))
            logger_log(logger, LOGGER_INFO, "AirGlass GPU queue: maximum=1 previous=%u", previous);
        else logger_log(logger, LOGGER_WARNING, "AirGlass GPU queue: device limit unavailable; normal presentation continues");
    }
#endif
}

static GstPadProbeReturn airglass_video_metrics(GstPad *pad, GstPadProbeInfo *info, gpointer user_data) {
    video_renderer_t *r = user_data;
    GstBuffer *buffer = GST_PAD_PROBE_INFO_BUFFER(info);
    if (!buffer || !r->airglass_low_latency) return GST_PAD_PROBE_OK;
    guint64 now = gst_element_get_current_running_time(r->pipeline);
    if (!GST_CLOCK_TIME_IS_VALID(now)) return GST_PAD_PROBE_OK;
    g_mutex_lock(&r->airglass_receipt_lock);
    airglass_receipt_t *item = airglass_find_receipt(r, GST_BUFFER_PTS(buffer), r->airglass_frame_pacing);
    memset(&r->airglass_pending_present, 0, sizeof(r->airglass_pending_present));
    if (item) {
        r->airglass_pending_present = *item;
        if (now >= item->arrival) { r->airglass_frames++; r->airglass_delay_total += now - item->arrival; }
    }
    if (!r->airglass_report_time) r->airglass_report_time = now;
    if (now - r->airglass_report_time >= 2 * GST_SECOND) {
        double elapsed = (now - r->airglass_report_time) / (double) GST_SECOND;
        double processing = r->airglass_frames ? r->airglass_delay_total / (double) r->airglass_frames / GST_MSECOND : -1;
        double decode = r->airglass_decode_samples ? r->airglass_decode_total / (double) r->airglass_decode_samples / GST_MSECOND : -1;
        double present = r->airglass_present_samples ? r->airglass_present_total / (double) r->airglass_present_samples / GST_MSECOND : -1;
        guint64 unmatched = r->airglass_unmatched;
        double budget = r->airglass_frame_pacing ? r->airglass_pacing.current_budget / (double) GST_MSECOND : 0;
        double jitter = r->airglass_frame_pacing ? r->airglass_pacing.jitter / (double) GST_MSECOND : 0;
        r->airglass_report_time = now;
        r->airglass_frames = r->airglass_delay_total = 0;
        r->airglass_decode_samples = r->airglass_decode_total = 0;
        r->airglass_present_samples = r->airglass_present_total = r->airglass_unmatched = 0;
        g_mutex_unlock(&r->airglass_receipt_lock);
        GstStructure *stats = NULL; guint64 rendered = 0, dropped = 0;
        GstElement *sink = gst_pad_get_parent_element(pad);
        if (sink && g_object_class_find_property(G_OBJECT_GET_CLASS(sink), "stats")) {
            g_object_get(sink, "stats", &stats, NULL);
            if (stats) {
                gst_structure_get_uint64(stats, "rendered", &rendered);
                gst_structure_get_uint64(stats, "dropped", &dropped);
                gst_structure_free(stats);
            }
        }
        if (sink) gst_object_unref(sink);
        guint64 delta_rendered = rendered >= r->airglass_previous_rendered ? rendered - r->airglass_previous_rendered : 0;
        guint64 delta_dropped = dropped >= r->airglass_previous_dropped ? dropped - r->airglass_previous_dropped : 0;
        r->airglass_previous_rendered = rendered; r->airglass_previous_dropped = dropped;
        logger_log(logger, LOGGER_INFO, "AirGlass metrics: rendered-fps=%.1f decode-ms=%.2f processing-ms=%.2f present-ms=%.2f pacing-ms=%.2f jitter-ms=%.2f late-dropped=%" G_GUINT64_FORMAT " unmatched=%" G_GUINT64_FORMAT,
                   delta_rendered / elapsed, decode, processing, present, budget, jitter, delta_dropped, unmatched);
        return GST_PAD_PROBE_OK;
    }
    g_mutex_unlock(&r->airglass_receipt_lock);
    return GST_PAD_PROBE_OK;
}

static void airglass_decoder_added(GstBin *bin, GstBin *sub_bin, GstElement *element, gpointer user_data) {
    video_renderer_t *r = user_data;
    GstElementFactory *factory = gst_element_get_factory(element);
    if (!factory) return;
    const gchar *klass = gst_element_factory_get_metadata(factory, GST_ELEMENT_METADATA_KLASS);
    if (!klass || !strstr(klass, "Decoder/Video")) return;
    const gchar *name = gst_plugin_feature_get_name(GST_PLUGIN_FEATURE(factory));
    if (r->airglass_low_latency && !strcmp(name,"d3d11h264dec") &&
        g_object_class_find_property(G_OBJECT_GET_CLASS(element),"compliance")) {
        gst_util_set_object_arg(G_OBJECT(element),"compliance","flexible");
        gint compliance=0;g_object_get(element,"compliance",&compliance,NULL);
        logger_log(logger,LOGGER_INFO,"AirGlass Direct3D11: low-delay H264 picture output enabled; compliance=%d",compliance);
    }
    if (r->airglass_low_latency && g_str_has_prefix(name, "nvh") &&
        g_object_class_find_property(G_OBJECT_GET_CLASS(element), "max-display-delay")) {
        gint checked = -1;
        g_object_set(element, "max-display-delay", 0, NULL);
        g_object_get(element, "max-display-delay", &checked, NULL);
        logger_log(logger, LOGGER_INFO, "AirGlass NVDEC: %s max-display-delay=%d", name, checked);
    }
    if (r->airglass_low_latency && g_str_has_prefix(name, "avdec_")) {
        if (g_object_class_find_property(G_OBJECT_GET_CLASS(element), "thread-type"))
            gst_util_set_object_arg(G_OBJECT(element), "thread-type", "slice");
        if (g_object_class_find_property(G_OBJECT_GET_CLASS(element), "max-threads"))
            g_object_set(element, "max-threads", 2, NULL);
    }
    logger_log(logger, LOGGER_INFO, "AirGlass decoder: %s (%s)", name,
               strstr(klass, "Hardware") ? "hardware" : "software");
}

static video_renderer_t *renderer = NULL;
static video_renderer_t *renderer_type[NCODECS] = {0};
static int n_renderers = NCODECS;
static char h264[] = "h264";
static char h265[] = "h265";
static char hls[] = "hls";

static void append_videoflip (GString *launch, const videoflip_t *flip, const videoflip_t *rot) {
    /* videoflip image transform */
    switch (*flip) {
    case INVERT:
        switch (*rot)  {
        case LEFT:
	    g_string_append(launch, "videoflip video-direction=GST_VIDEO_ORIENTATION_90R ! ");
	    break;
        case RIGHT:
            g_string_append(launch, "videoflip video-direction=GST_VIDEO_ORIENTATION_90L ! ");
            break;
        default:
	    g_string_append(launch, "videoflip video-direction=GST_VIDEO_ORIENTATION_180 ! ");
	    break;
        }
        break;
    case HFLIP:
        switch (*rot) {
        case LEFT:
            g_string_append(launch, "videoflip video-direction=GST_VIDEO_ORIENTATION_UL_LR ! ");
            break;
        case RIGHT:
            g_string_append(launch, "videoflip video-direction=GST_VIDEO_ORIENTATION_UR_LL ! ");
            break;
        default:
            g_string_append(launch, "videoflip video-direction=GST_VIDEO_ORIENTATION_HORIZ ! ");
            break;
        }
        break;
    case VFLIP:
        switch (*rot) {
        case LEFT:
            g_string_append(launch, "videoflip video-direction=GST_VIDEO_ORIENTATION_UR_LL ! ");
            break;
        case RIGHT:
            g_string_append(launch, "videoflip video-direction=GST_VIDEO_ORIENTATION_UL_LR ! ");
            break;
        default:
            g_string_append(launch, "videoflip video-direction=GST_VIDEO_ORIENTATION_VERT ! ");
	  break;
	}
        break;
    default:
        switch (*rot) {
        case LEFT:
            g_string_append(launch, "videoflip video-direction=GST_VIDEO_ORIENTATION_90L ! ");
            break;
        case RIGHT:
            g_string_append(launch, "videoflip video-direction=GST_VIDEO_ORIENTATION_90R ! ");
            break;
        default:
            break;
        }
        break;
    }
}

/* apple uses colorimetry that is detected as  1:3:7:1           * //previously 1:3:5:1 was seen
 * (not recognized by v4l2 plugin in Gstreamer  < 1.20.4)        *
 * See .../gst-libs/gst/video/video-color.h in gst-plugins-base  *
 * range = 1   -> GST_VIDEO_COLOR_RANGE_0_255      ("full RGB")  * 
 * matrix = 3  -> GST_VIDEO_COLOR_MATRIX_BT709                   *
 * transfer = 7 -> GST_VIDEO_TRANSFER_SRGB                       * // previously GST_VIDEO_TRANSFER_BT709
 * primaries = 1 -> GST_VIDEO_COLOR_PRIMARIES_BT709              *
 * closest used by  GStreamer < 1.20.4 is BT709, 2:3:5:1 with    * // now use sRGB = 1:1:7:1    
 * range = 2 -> GST_VIDEO_COLOR_RANGE_16_235 ("limited RGB")     */  

static const char h264_caps[]="video/x-h264,stream-format=(string)byte-stream,alignment=(string)au";
static const char h265_caps[]="video/x-h265,stream-format=(string)byte-stream,alignment=(string)au";

void video_renderer_size(float *f_width_source, float *f_height_source, float *f_width, float *f_height) {
    width_source = (unsigned short) *f_width_source;
    height_source = (unsigned short) *f_height_source;
    width = (unsigned short) *f_width;
    height = (unsigned short) *f_height;
    logger_log(logger, LOGGER_DEBUG, "begin video stream wxh = %dx%d; source %dx%d", width, height, width_source, height_source);
}

GstElement *make_video_sink(const char *videosink, const char *videosink_options) {
  /* used to build a videosink for playbin, using the user-specified string "videosink" */ 
    GstElement *video_sink = gst_element_factory_make(videosink, "videosink");
    if (!video_sink) {
        return NULL;
    }

    /* process the video_sink_options */
    size_t len = strlen(videosink_options);
    if (!len) {
        return video_sink;
    }

    char *options  = (char *) malloc(len + 1);
    strncpy(options, videosink_options, len + 1);

    /* remove any extension begining with "!" */
    char *end = strchr(options, '!');
    if (end) {   
      *end = '\0';
    }

    /* add any fullscreen options "property=pval" included in string videosink_options*/    
    /* OK to use strtok_r in Windows with MSYS2 (POSIX); use strtok_s for MSVC */
    char *token;
    char *text = options;

    while((token = strtok_r(text, " ", &text))) {
	char *pval = strchr(token, '=');
        if (pval) {
            *pval = '\0';
            pval++;
            const gchar *property_name = (const gchar *) token;
            const gchar *value = (const gchar *) pval;
	    g_print("playbin_videosink property: \"%s\" \"%s\"\n", property_name, value);
	    gst_util_set_object_arg(G_OBJECT (video_sink), property_name, value);
        }
    }
    free(options);
    return video_sink;
}

void  video_renderer_init(logger_t *render_logger, const char *server_name, videoflip_t videoflip[2], const char *parser,
                          const char *decoder, const char *converter, const char *videosink, const char *videosink_options, 
                          bool initial_fullscreen, bool video_sync, bool h265_support, guint playbin_version, const char *uri) {
    GError *error = NULL;
    GstCaps *caps = NULL;
    hls_video = (uri != NULL);
    /* videosink choices that are auto */
    auto_videosink = (strstr(videosink, "autovideosink") || strstr(videosink, "fpsdisplaysink"));

    logger = render_logger;
#ifdef _WIN32
    if (!airglass_precise_timer && g_strcmp0(g_getenv("AIRGLASS_LOW_LATENCY"),"1")==0) {
        airglass_precise_timer=timeBeginPeriod(1)==TIMERR_NOERROR;
        logger_log(logger,LOGGER_INFO,"AirGlass timer: %s",airglass_precise_timer ? "1 ms receiver scheduling" : "Windows default scheduling");
    }
#endif
    airglass_prefer_decoders(g_getenv("AIRGLASS_DECODER"), logger);
    logger_debug = (logger_get_level(logger) >= LOGGER_DEBUG);
    video_terminate = false;
    hls_seek_enabled = FALSE;
    hls_playing = FALSE;
    hls_seek_start = -1;
    hls_seek_end = -1;
    hls_duration = -1;
    hls_buffer_empty = TRUE;
    hls_buffer_empty = FALSE;
    

    /* this call to g_set_application_name makes server_name appear in the  X11 display window title bar, */
    /* (instead of the program name uxplay taken from (argv[0]). It is only set one time. */

    const gchar *appname = g_get_application_name();
    if (!appname || strcmp(appname,server_name))  g_set_application_name(server_name);
    appname = NULL;

    /* the renderer for hls video will only be built if a HLS uri is provided in 
     * the call to video_renderer_init, in which case the h264 and 265 mirror-mode 
     * renderers will not be built.   This is because it appears that we cannot  
     * put playbin into GST_STATE_READY before knowing the uri (?), so cannot use a
     * unified renderer structure with h264, h265 and hls  */  
    if (hls_video) {
        n_renderers = 1;
    } else {
        n_renderers = h265_support ? 2 : 1;
    }
    g_assert (n_renderers <= NCODECS);
    for (int i = 0; i < n_renderers; i++) {
        g_assert (i < 2);
        renderer_type[i] = (video_renderer_t *) calloc(1, sizeof(video_renderer_t));
        g_assert(renderer_type[i]);
        g_mutex_init(&renderer_type[i]->airglass_receipt_lock);
        renderer_type[i]->autovideo = auto_videosink;
        renderer_type[i]->id = i;
        renderer_type[i]->bus = NULL;
        if (hls_video) {
            /* use playbin3 to play HLS video: replace "playbin3" by "playbin" to use playbin2 */
            switch (playbin_version)  {
            case 2:
                renderer_type[i]->pipeline = gst_element_factory_make("playbin", "hls-playbin2");
                break;
            case 3:
                renderer_type[i]->pipeline = gst_element_factory_make("playbin3", "hls-playbin3");
                break;
            default:
                logger_log(logger, LOGGER_ERR, "video_renderer_init: invalid playbin version %u", playbin_version);
                g_assert(0);
            }
            logger_log(logger, LOGGER_INFO, "Will use GStreamer playbin version %u to play HLS streamed video", playbin_version);	    
            g_assert(renderer_type[i]->pipeline);
            renderer_type[i]->appsrc = NULL;
	    renderer_type[i]->codec = hls;
            /* if we are not using autovideosink, build a videossink based on the string "videosink" */
            if(strcmp(videosink, "autovideosink")) {
                GstElement *playbin_videosink = make_video_sink(videosink, videosink_options);  
                if (!playbin_videosink) {
                    logger_log(logger, LOGGER_ERR, "video_renderer_init: failed to create playbin_videosink");
                } else {
                    logger_log(logger, LOGGER_DEBUG, "video_renderer_init: create playbin_videosink at %p", playbin_videosink);
                    g_object_set(G_OBJECT (renderer_type[i]->pipeline), "video-sink", playbin_videosink, NULL);
                }
            }
            gint flags;
            g_object_get(renderer_type[i]->pipeline, "flags", &flags, NULL);
            flags |= GST_PLAY_FLAG_DOWNLOAD;
	    flags |= GST_PLAY_FLAG_BUFFERING;    // set by default in playbin3, but not in playbin2; is it needed?
            g_object_set(renderer_type[i]->pipeline, "flags", flags, NULL);
	    g_object_set (G_OBJECT (renderer_type[i]->pipeline), "uri", uri, NULL);
        } else {
            switch (i) {
            case 0:
                renderer_type[i]->codec = h264;
                caps = gst_caps_from_string(h264_caps);
                break;
            case 1:
                renderer_type[i]->codec = h265;
                caps = gst_caps_from_string(h265_caps);
                break;
            default:
                g_assert(0);
            }
            gboolean fast = g_strcmp0(g_getenv("AIRGLASS_LOW_LATENCY"), "1") == 0;
            gboolean gpu = g_strcmp0(g_getenv("AIRGLASS_GPU_RENDERER"), "1") == 0 && !strcmp(videosink, "d3d11videosink");
            GstElementFactory *gpu_factory = gpu ? gst_element_factory_find("d3d11convert") : NULL;
            gpu = gpu_factory != NULL;
            if (gpu_factory) gst_object_unref(gpu_factory);
            renderer_type[i]->airglass_low_latency = fast;
            gboolean paced = fast && g_strcmp0(g_getenv("AIRGLASS_FRAME_PACING"), "1") == 0;
            const gchar *fps_text = g_getenv("AIRGLASS_FPS");
            gint fps = fps_text ? atoi(fps_text) : 30;
            if (fps != 15 && fps != 30 && fps != 60) fps = 30;
            renderer_type[i]->airglass_frame_pacing = paced;
            renderer_type[i]->airglass_frame_budget = GST_SECOND / fps;
            GString *launch = g_string_new("appsrc name=video_source ! ");
            /* This encoded queue blocks; it never leaks reference packets. */
            g_string_append(launch, fast ? "queue max-size-buffers=1 max-size-bytes=0 max-size-time=0 ! "
                                        : "queue max-size-buffers=8 max-size-bytes=0 max-size-time=0 ! ");
            g_string_append(launch, parser);
            g_string_append(launch, " ! ");
            g_string_append(launch, decoder);
            g_string_append(launch, " ! ");
            if (fast) g_string_append(launch, "identity name=airglass_decoded silent=true ! ");
            append_videoflip(launch, &videoflip[0], &videoflip[1]);
            if (fast) g_string_append(launch, "queue max-size-buffers=1 max-size-bytes=0 max-size-time=0 leaky=downstream silent=true ! ");
            if (gpu) {
                /* Upload is passthrough for GPU frames and accepts CPU fallback. */
                g_string_append(launch, ""); /* Sink directly accepts NV12/P010 GPU textures and CPU fallback. */
            } else {
                g_string_append(launch, converter);
                g_string_append(launch, " ! videoscale ! ");
            }
            g_string_append(launch, videosink);
            g_string_append(launch, " name=");
            g_string_append(launch, videosink);
            g_string_append(launch, "_");
            g_string_append(launch, renderer_type[i]->codec);
            g_string_append(launch, videosink_options);
            if (fast) g_string_append(launch, " qos=false enable-last-sample=false");
            if (paced) {
                g_string_append_printf(launch, " sync=true max-lateness=%" G_GUINT64_FORMAT,
                                       renderer_type[i]->airglass_frame_budget);
                sync = false; /* Pacing uses relative capture time, not absolute NTP waits. */
            } else if (video_sync) {
                g_string_append(launch, " sync=true");
                sync = true;
            } else {
                g_string_append(launch, " sync=false");
                sync = false;
            }

            if (!strcmp(renderer_type[i]->codec, h264)) {
                char *pos = launch->str;
                while ((pos = strstr(pos,h265))){
                    pos +=3;
                    *pos = '4';
                }
            } else if (!strcmp(renderer_type[i]->codec, h265)) {
                char *pos = launch->str;
                while ((pos = strstr(pos,h264))){
                    pos +=3;
                    *pos = '5';
                }
            }

            logger_log(logger, LOGGER_DEBUG, "GStreamer video pipeline %d:\n\"%s\"", i + 1, launch->str);
            renderer_type[i]->pipeline = gst_parse_launch(launch->str, &error);
            if (error) {
                logger_log(logger, LOGGER_ERR, "GStreamer gst_parse_launch failed to create video pipeline %d\n"
                           "*** error message from gst_parse_launch was:\n%s\n"
                           "launch string parsed was \n[%s]", i + 1, error->message, launch->str);
		if (strstr(error->message, "no element")) {
                    logger_log(logger, LOGGER_ERR, "This error usually means that a uxplay option was mistyped\n"
                               "           or some requested part of GStreamer is not installed\n");
                }
                g_clear_error (&error);
            }
            g_assert (renderer_type[i]->pipeline);
            if (paced) gst_pipeline_set_latency(GST_PIPELINE(renderer_type[i]->pipeline), 0);
            g_signal_connect(renderer_type[i]->pipeline, "deep-element-added", G_CALLBACK(airglass_decoder_added), renderer_type[i]);
            /* Explicit software decoders already exist before the dynamic signal is connected. */
            GstIterator *elements = gst_bin_iterate_recurse(GST_BIN(renderer_type[i]->pipeline));
            GValue element_value = G_VALUE_INIT;
            while (gst_iterator_next(elements, &element_value) == GST_ITERATOR_OK) {
                airglass_decoder_added(NULL, NULL, GST_ELEMENT(g_value_get_object(&element_value)), renderer_type[i]);
                g_value_reset(&element_value);
            }
            g_value_unset(&element_value); gst_iterator_free(elements);
            logger_log(logger, LOGGER_INFO, "AirGlass renderer: %s; encoded queue=%u; decoded queue=%s",
                       gpu ? "Direct3D11 direct texture display" : "CPU compatibility conversion/display",
                       fast ? 1 : 8, fast ? "latest frame" : "preserve frames");
            if (fast) logger_log(logger, LOGGER_INFO, "AirGlass pacing: %s; ceiling=%.2f ms",
                                 paced ? "adaptive after decode" : "immediate display",
                                 paced ? renderer_type[i]->airglass_frame_budget / (double) GST_MSECOND : 0.0);
            GstElement *decoded = gst_bin_get_by_name(GST_BIN(renderer_type[i]->pipeline), "airglass_decoded");
            if (decoded) {
                GstPad *decoded_pad = gst_element_get_static_pad(decoded, "src");
                gst_pad_add_probe(decoded_pad, GST_PAD_PROBE_TYPE_BUFFER | GST_PAD_PROBE_TYPE_EVENT_DOWNSTREAM,
                                  airglass_decoded_frame, renderer_type[i], NULL);
                gst_object_unref(decoded_pad); gst_object_unref(decoded);
            }
            gchar *sink_name = g_strdup_printf("%s_%s", videosink, renderer_type[i]->codec);
            GstElement *sink_element = gst_bin_get_by_name(GST_BIN(renderer_type[i]->pipeline), sink_name);
            if (sink_element) {
                if (fast && g_signal_lookup("present", G_OBJECT_TYPE(sink_element)) &&
                    g_object_class_find_property(G_OBJECT_GET_CLASS(sink_element), "emit-present")) {
                    g_object_set(sink_element, "emit-present", TRUE, NULL);
                    g_signal_connect(sink_element, "present", G_CALLBACK(airglass_present), renderer_type[i]);
                }
                GstPad *sink_pad = gst_element_get_static_pad(sink_element, "sink");
                if (sink_pad) { gst_pad_add_probe(sink_pad, GST_PAD_PROBE_TYPE_BUFFER, airglass_video_metrics, renderer_type[i], NULL); gst_object_unref(sink_pad); }
                gst_object_unref(sink_element);
            }
            g_free(sink_name);

            GstClock *clock = gst_system_clock_obtain();
            g_object_set(clock, "clock-type", fast ? GST_CLOCK_TYPE_MONOTONIC : GST_CLOCK_TYPE_REALTIME, NULL);
            gst_pipeline_use_clock(GST_PIPELINE_CAST(renderer_type[i]->pipeline), clock);
            renderer_type[i]->appsrc = gst_bin_get_by_name (GST_BIN (renderer_type[i]->pipeline), "video_source");
            g_assert(renderer_type[i]->appsrc);

            g_object_set(renderer_type[i]->appsrc, "caps", caps, "stream-type", 0, "is-live", TRUE, "format", GST_FORMAT_TIME, NULL);
            /* UxPlay's default nonblocking appsrc could ignore enough-data and grow indefinitely. */
            g_object_set(renderer_type[i]->appsrc, "max-buffers", (guint64) (fast ? 1 : 8), "max-bytes", (guint64) 0,
                         "max-time", (guint64) 0, "block", TRUE, NULL);
            g_string_free(launch, TRUE);
            gst_caps_unref(caps);
	    gst_object_unref(clock);
        }	
#ifdef X_DISPLAY_FIX
        use_x11 = (strstr(videosink, "xvimagesink") || strstr(videosink, "ximagesink") || auto_videosink);
        fullscreen = initial_fullscreen;
        renderer_type[i]->server_name = server_name;
        renderer_type[i]->gst_window = NULL;
        renderer_type[i]->use_x11 = false;
        X11_search_attempts = 0;
	/* setting char *x11_display_name to NULL means the value is taken from $DISPLAY in the environment 
         * (a uxplay option to specify a different value is possible)  */
	char *x11_display_name = NULL;
        if (use_x11) {
            if (i == 0) {
                renderer_type[0]->gst_window = (X11_Window_t *) calloc(1, sizeof(X11_Window_t));
                g_assert(renderer_type[0]->gst_window);
                get_X11_Display(renderer_type[0]->gst_window, x11_display_name);
                if (renderer_type[0]->gst_window->display) {
                    renderer_type[i]->use_x11 = true;
                } else {
                    free(renderer_type[0]->gst_window);
                    renderer_type[0]->gst_window = NULL;
                }
            } else if (renderer_type[0]->use_x11) {
                renderer_type[i]->gst_window = (X11_Window_t *) calloc(1, sizeof(X11_Window_t));
                g_assert(renderer_type[i]->gst_window);
                memcpy(renderer_type[i]->gst_window, renderer_type[0]->gst_window, sizeof(X11_Window_t));
                renderer_type[i]->use_x11 = true;
            }
        }
#endif
        gst_element_set_state (renderer_type[i]->pipeline, GST_STATE_READY);
        GstState state;
        if (gst_element_get_state (renderer_type[i]->pipeline, &state, NULL, 100 * GST_MSECOND)) {
            if (state == GST_STATE_READY) {
                logger_log(logger, LOGGER_DEBUG, "Initialized GStreamer video renderer %d", i + 1);
                if (hls_video && i == 0) {
                    renderer = renderer_type[i];
                }
            } else {
                logger_log(logger, LOGGER_ERR, "Failed to initialize GStreamer video renderer %d", i + 1);
            }
        } else {
            logger_log(logger, LOGGER_ERR, "Failed to initialize GStreamer video renderer %d", i + 1);
        }
    }
}

void video_renderer_pause() {
    if (!renderer) {
        return;
    }
    logger_log(logger, LOGGER_DEBUG, "video renderer paused");
    gst_element_set_state(renderer->pipeline, GST_STATE_PAUSED);
}

void video_renderer_resume() {
    if (!renderer) {
        return;
    }
    gst_element_set_state (renderer->pipeline, GST_STATE_PLAYING);
    GstState state;
    /* wait with timeout 100 msec for pipeline to change state from PAUSED to PLAYING */
    gst_element_get_state(renderer->pipeline, &state, NULL, 100 * GST_MSECOND);
    const gchar *state_name = gst_element_state_get_name(state);
    logger_log(logger, LOGGER_DEBUG, "video renderer resumed: state %s", state_name);
    if (renderer->appsrc) {
        gst_video_pipeline_base_time = gst_element_get_base_time(renderer->appsrc);
    }
}

void video_renderer_start() {
    GstState state;
    const gchar *state_name;
    if (hls_video) {
        renderer->bus = gst_element_get_bus(renderer->pipeline);
        gst_element_set_state (renderer->pipeline, GST_STATE_PAUSED);
	gst_element_get_state(renderer->pipeline, &state, NULL, 1000 * GST_MSECOND);
	state_name= gst_element_state_get_name(state);
	logger_log(logger, LOGGER_DEBUG, "video renderer_start: state %s", state_name);
        return;
    } 
  /* when not hls, start both h264 and h265 pipelines; will shut down the "wrong" one when we know the codec */
    for (int i = 0; i < n_renderers; i++) {
        renderer_type[i]->airglass_report_time = 0;
        renderer_type[i]->airglass_frames = 0;
        renderer_type[i]->airglass_delay_total = 0;
        g_mutex_lock(&renderer_type[i]->airglass_receipt_lock);
        memset(&renderer_type[i]->airglass_pacing, 0, sizeof(renderer_type[i]->airglass_pacing));
        memset(renderer_type[i]->airglass_receipts, 0, sizeof(renderer_type[i]->airglass_receipts));
        memset(&renderer_type[i]->airglass_pending_present, 0, sizeof(renderer_type[i]->airglass_pending_present));
        renderer_type[i]->airglass_receipt_index = 0;
        renderer_type[i]->airglass_decode_total = renderer_type[i]->airglass_decode_samples = 0;
        renderer_type[i]->airglass_present_total = renderer_type[i]->airglass_present_samples = 0;
        renderer_type[i]->airglass_previous_rendered = renderer_type[i]->airglass_previous_dropped = 0;
        renderer_type[i]->airglass_last_present_seq = renderer_type[i]->airglass_unmatched = 0;
        renderer_type[i]->airglass_gpu_device = NULL;
        g_mutex_unlock(&renderer_type[i]->airglass_receipt_lock);
        renderer_type[i]->bus = gst_element_get_bus(renderer_type[i]->pipeline);
        gst_element_set_state (renderer_type[i]->pipeline, GST_STATE_PAUSED);
	gst_element_get_state(renderer_type[i]->pipeline, &state, NULL, 1000 * GST_MSECOND);
	state_name= gst_element_state_get_name(state);
	logger_log(logger, LOGGER_DEBUG, "video renderer_start: renderer %d state %s", i, state_name);
    }
    renderer = NULL;
    first_packet = true;
#ifdef X_DISPLAY_FIX
    X11_search_attempts = 0;
#endif
}

/* used to find any X11 Window used by the playbin (HLS) pipeline after it starts playing. 
*  if use_x11 is true, called every 100 ms after playbin state is READY until the x11 window is found*/
bool waiting_for_x11_window() {
    if (!hls_video) {
        return false;
    }
#ifdef X_DISPLAY_FIX
    if (use_x11 && renderer->gst_window) {
        get_x_window(renderer->gst_window, renderer->server_name);
        if (!renderer->gst_window->window) {
	    return true;    /* window still not found */
        }
    }
    if (fullscreen) {
         set_fullscreen(renderer->gst_window, &fullscreen);
    }
#endif
    return false;
}

uint64_t video_renderer_render_buffer(unsigned char* data, int *data_len, int *nal_count, uint64_t *ntp_time) {
    GstBuffer *buffer;
    GstClockTime pts = (GstClockTime) *ntp_time; /*now in nsecs */
    //GstClockTimeDiff latency = GST_CLOCK_DIFF(gst_element_get_current_clock_time (renderer->appsrc), pts);
    if (sync) {
        if (pts >= gst_video_pipeline_base_time) {
            pts -= gst_video_pipeline_base_time;
        } else {
            // adjust timestamps to be >= gst_video_pipeline_base time
            logger_log(logger, LOGGER_DEBUG, "*** invalid ntp_time < gst_video_pipeline_base_time\n%8.6f ntp_time\n%8.6f base_time",
                       ((double) *ntp_time) / SECOND_IN_NSECS, ((double) gst_video_pipeline_base_time) / SECOND_IN_NSECS);
            return  (uint64_t)  gst_video_pipeline_base_time - pts;
        }
    }
    g_assert(data_len != 0);
    /* first four bytes of valid  h264  video data are 0x00, 0x00, 0x00, 0x01.    *
     * nal_count is the number of NAL units in the data: short SPS, PPS, SEI NALs *
     * may  precede a VCL NAL. Each NAL starts with 0x00 0x00 0x00 0x01 and is    *
     * byte-aligned: the first byte of invalid data (decryption failed) is 0x01   */
    if (data[0]) {
        logger_log(logger, LOGGER_ERR, "*** ERROR decryption of video packet failed ");
    } else {
        if (first_packet) {
            logger_log(logger, LOGGER_INFO, "Begin streaming to GStreamer video pipeline");
            first_packet = false;
        }
        buffer = gst_buffer_new_allocate(NULL, *data_len, NULL);
        g_assert(buffer != NULL);
        //g_print("video latency %8.6f\n", (double) latency / SECOND_IN_NSECS);
        if (sync) {
            GST_BUFFER_PTS(buffer) = pts;
        } else if (renderer->airglass_low_latency) {
            guint64 receipt = gst_element_get_current_running_time(renderer->pipeline);
            GST_BUFFER_PTS(buffer) = receipt;
            if (GST_CLOCK_TIME_IS_VALID(receipt)) {
                g_mutex_lock(&renderer->airglass_receipt_lock);
                guint64 sequence = ++renderer->airglass_receipt_index;
                airglass_receipt_t *item = &renderer->airglass_receipts[sequence % AIRGLASS_RECEIPTS];
                item->input_pts = item->scheduled_pts = receipt;
                item->arrival = receipt; item->capture = *ntp_time;
                item->decoded = 0; item->sequence = sequence;
                g_mutex_unlock(&renderer->airglass_receipt_lock);
            }
        }
        gst_buffer_fill(buffer, 0, data, *data_len);
        gst_app_src_push_buffer (GST_APP_SRC(renderer->appsrc), buffer);
#ifdef X_DISPLAY_FIX
        if (renderer->gst_window && !(renderer->gst_window->window) && renderer->use_x11) {
            X11_search_attempts++;
            logger_log(logger, LOGGER_DEBUG, "Looking for X11 UxPlay Window, attempt %d", (int) X11_search_attempts);
            get_x_window(renderer->gst_window, renderer->server_name);
            if (renderer->gst_window->window) {
                logger_log(logger, LOGGER_INFO, "\n*** X11 Windows: Use key F11 or (left Alt)+Enter to toggle full-screen mode\n");
                if (fullscreen) {
                    set_fullscreen(renderer->gst_window, &fullscreen);
                }
            }
        }
#endif
    }
    return 0;
}

void video_renderer_flush() {
}

void video_renderer_stop() {
    if (renderer) {
        if (renderer->appsrc) {
            gst_app_src_end_of_stream (GST_APP_SRC(renderer->appsrc));
        }
        gst_element_set_state (renderer->pipeline, GST_STATE_NULL);
        //gst_element_set_state (renderer->playbin, GST_STATE_NULL);
     }
}

static void video_renderer_destroy_instance(video_renderer_t *renderer) {
    if (renderer) {
        logger_log(logger, LOGGER_DEBUG,"destroying renderer instance %p", renderer);
        GstState state;
	GstStateChangeReturn ret;
        gst_element_get_state(renderer->pipeline, &state, NULL, 100 * GST_MSECOND);
	logger_log(logger, LOGGER_DEBUG,"pipeline state is %s", gst_element_state_get_name(state));
        if (state != GST_STATE_NULL) {
            if (!hls_video) {
                gst_app_src_end_of_stream (GST_APP_SRC(renderer->appsrc));
            }
            ret = gst_element_set_state (renderer->pipeline, GST_STATE_NULL);
	    logger_log(logger, LOGGER_DEBUG,"pipeline state change to NULL: %s",
		       gst_element_state_change_return_get_name(ret));
	    gst_element_get_state(renderer->pipeline, NULL, NULL, 1000 * GST_MSECOND);
        }
        gst_object_unref(renderer->bus);
	if (renderer->appsrc) {
            gst_object_unref (renderer->appsrc);
        }
        gst_object_unref (renderer->pipeline);
#ifdef X_DISPLAY_FIX
        if (renderer->gst_window) {
            free(renderer->gst_window);
            renderer->gst_window = NULL;
        }
#endif
        g_mutex_clear(&renderer->airglass_receipt_lock);
        free (renderer);
        renderer = NULL;
    }
}

void video_renderer_destroy() {
#ifdef _WIN32
    if(airglass_precise_timer){timeEndPeriod(1);airglass_precise_timer=FALSE;}
#endif
    for (int i = 0; i < n_renderers; i++) {
        if (renderer_type[i]) {
            if(renderer==renderer_type[i])renderer=NULL;
            video_renderer_destroy_instance(renderer_type[i]);
            renderer_type[i]=NULL;
        }
    }
}

gboolean gstreamer_pipeline_bus_callback(GstBus *bus, GstMessage *message, void *loop) {

  /* identify which pipeline sent the message */ 
    int type = -1;
    for (int i = 0 ; i < n_renderers ; i ++ ) {
        if (renderer_type[i] && renderer_type[i]->bus == bus) {
            type = i;
            break;
        }
    }
    /* if the bus sending the message is not found, the renderer may already have been destroyed */
    if (type == -1) {
        return TRUE;
    }

    if (logger_debug) {
        if (hls_video) {
            gint64 pos;
            const gchar no_state[] = "";
            const gchar *old_state_name, *new_state_name;
            if (GST_MESSAGE_TYPE(message) == GST_MESSAGE_STATE_CHANGED) {
                GstState old_state, new_state;
                gst_message_parse_state_changed (message, &old_state, &new_state, NULL);
                old_state_name = gst_element_state_get_name (old_state);
                new_state_name = gst_element_state_get_name (new_state);
            } else {
                 old_state_name = no_state;
                 new_state_name = no_state;
            }
            gst_element_query_position (renderer_type[type]->pipeline, GST_FORMAT_TIME, &pos);
            if (GST_CLOCK_TIME_IS_VALID(pos)) {
                g_print("GStreamer bus message %s %s %s %s; position: %" GST_TIME_FORMAT "\n", GST_MESSAGE_SRC_NAME(message),
			GST_MESSAGE_TYPE_NAME(message), old_state_name, new_state_name, GST_TIME_ARGS(pos));
            } else {
                g_print("GStreamer bus message %s %s %s %s; position: none\n", GST_MESSAGE_SRC_NAME(message),
			GST_MESSAGE_TYPE_NAME(message), old_state_name, new_state_name);
            }
        } else {
            g_print("GStreamer %s bus message: %s %s\n", renderer_type[type]->codec, GST_MESSAGE_SRC_NAME(message), GST_MESSAGE_TYPE_NAME(message));
        }
    }

    /* monitor hls video position until seek to hls_start_position is achieved */
    if (hls_video && hls_requested_start_position) {
        if (strstr(GST_MESSAGE_SRC_NAME(message), "sink")) {	  
            gint64 pos;
            if (!GST_CLOCK_TIME_IS_VALID(hls_duration)) {
                gst_element_query_duration (renderer->pipeline, GST_FORMAT_TIME, &hls_duration);
            }
	    gst_element_query_position (renderer_type[type]->pipeline, GST_FORMAT_TIME, &pos);
            //g_print("HLS position %" GST_TIME_FORMAT " requested_start_position %" GST_TIME_FORMAT " duration %" GST_TIME_FORMAT " %s\n",
            //    GST_TIME_ARGS(pos), GST_TIME_ARGS(hls_requested_start_position), GST_TIME_ARGS(hls_duration),
            //    (hls_seek_enabled ? "seek enabled" : "seek not enabled"));
            if (pos > hls_requested_start_position) {
                hls_requested_start_position = 0;
            }
	    if ( hls_requested_start_position && pos < hls_requested_start_position  && hls_seek_enabled) {
                g_print("***************** seek to hls_requested_start_position %" GST_TIME_FORMAT "\n", GST_TIME_ARGS(hls_requested_start_position));
                if (gst_element_seek_simple (renderer_type[type]->pipeline, GST_FORMAT_TIME,
                                            GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_KEY_UNIT, hls_requested_start_position)) {
                    hls_requested_start_position = 0;
                }
	    }
	}
    }

    switch (GST_MESSAGE_TYPE (message)) {
    case GST_MESSAGE_DURATION:
        hls_duration = GST_CLOCK_TIME_NONE;
        break;
    case GST_MESSAGE_BUFFERING:
        if (hls_video) {
            gint percent = -1;
            gst_message_parse_buffering(message, &percent);
            hls_buffer_empty = TRUE;
	    hls_buffer_full = FALSE;
	    if (percent > 0) {
                hls_buffer_empty = FALSE;
                renderer_type[type]->buffering_level = percent;
                logger_log(logger, LOGGER_DEBUG, "Buffering :%d percent done", percent);
                if (percent < 100) {
                    gst_element_set_state (renderer_type[type]->pipeline, GST_STATE_PAUSED);
                } else {
                    hls_buffer_full = TRUE;
                    gst_element_set_state (renderer_type[type]->pipeline, GST_STATE_PLAYING);
                }
            }
        }
	break;      
    case GST_MESSAGE_ERROR: {
        GError *err;
        gchar *debug;
        gboolean flushing;
        gst_message_parse_error (message, &err, &debug);
        logger_log(logger, LOGGER_INFO, "GStreamer error: %s %s", GST_MESSAGE_SRC_NAME(message),err->message);
        if (!hls_video && strstr(err->message,"Internal data stream error")) {
            logger_log(logger, LOGGER_INFO,
                     "*** This is a generic GStreamer error that usually means that GStreamer\n"
                     "*** was unable to construct a working video pipeline.\n\n"
                     "*** If you are letting the default autovideosink select the videosink,\n"
                     "*** GStreamer may be trying to use non-functional hardware h264 video decoding.\n"
                     "*** Try using option -avdec to force software decoding or use -vs <videosink>\n"
                     "*** to select a videosink of your choice (see \"man uxplay\").\n\n"
                     "*** Raspberry Pi models 4B and earlier using Video4Linux2 may need \"-bt709\" uxplay option");
        }
	g_error_free (err);
        g_free (debug);
	if (renderer_type[type]->appsrc) {
            gst_app_src_end_of_stream (GST_APP_SRC(renderer_type[type]->appsrc));
	}
        gst_bus_set_flushing(bus, TRUE);
        gst_element_set_state (renderer_type[type]->pipeline, GST_STATE_READY);
        renderer_type[type]->terminate = TRUE;
        g_main_loop_quit( (GMainLoop *) loop);
        break;
    }
    case GST_MESSAGE_EOS:
      /* end-of-stream */
        logger_log(logger, LOGGER_INFO, "GStreamer: End-Of-Stream");
	if (hls_video) {
            gst_bus_set_flushing(bus, TRUE);
            gst_element_set_state (renderer_type[type]->pipeline, GST_STATE_READY);
	    renderer_type[type]->terminate = TRUE;
            g_main_loop_quit( (GMainLoop *) loop);
        }
        break;
    case GST_MESSAGE_STATE_CHANGED:
        if (hls_video && logger_debug && strstr(GST_MESSAGE_SRC_NAME(message), "hls-playbin")) {
            GstState old_state, new_state;
            gst_message_parse_state_changed (message, &old_state, &new_state, NULL);
            g_print ("****** hls_playbin: Element %s changed state from %s to %s.\n", GST_OBJECT_NAME (message->src),
                     gst_element_state_get_name (old_state),
                     gst_element_state_get_name (new_state));
            if (new_state != GST_STATE_PLAYING) {
                break;
                hls_playing = FALSE;
            }
            hls_playing = TRUE;
            GstQuery *query;
            query = gst_query_new_seeking(GST_FORMAT_TIME);
                if (gst_element_query(renderer->pipeline, query)) {
	        gst_query_parse_seeking (query, NULL, &hls_seek_enabled, &hls_seek_start, &hls_seek_end);
                if (hls_seek_enabled) {
                    g_print ("Seeking is ENABLED from %" GST_TIME_FORMAT " to %" GST_TIME_FORMAT "\n",
			     GST_TIME_ARGS (hls_seek_start), GST_TIME_ARGS (hls_seek_end));
                } else {
                    g_print ("Seeking is DISABLED for this stream.\n");
                }
            } else {
                g_printerr ("Seeking query failed.");
            }
            gst_query_unref (query);
        }
        if (renderer_type[type]->autovideo) {
            char *sink = strstr(GST_MESSAGE_SRC_NAME(message), "-actual-sink-");
            if (sink) {
                sink += strlen("-actual-sink-");
		if (strstr(GST_MESSAGE_SRC_NAME(message), renderer_type[type]->codec)) {
                    logger_log(logger, LOGGER_DEBUG, "GStreamer: automatically-selected videosink"
                               " (renderer %d: %s) is \"%ssink\"", renderer_type[type]->id + 1,
                               renderer_type[type]->codec, sink);
#ifdef X_DISPLAY_FIX
                    renderer_type[type]->use_x11 = (strstr(sink, "ximage") || strstr(sink, "xvimage"));
#endif
		    renderer_type[type]->autovideo = false;
                }
            }
        }
        break;
#ifdef  X_DISPLAY_FIX
    case GST_MESSAGE_ELEMENT:
        if (renderer_type[type]->gst_window && renderer_type[type]->gst_window->window) {
            GstNavigationMessageType message_type = gst_navigation_message_get_type (message);
            if (message_type == GST_NAVIGATION_MESSAGE_EVENT) {
                GstEvent *event = NULL;
                if (gst_navigation_message_parse_event (message, &event)) {
                    GstNavigationEventType event_type = gst_navigation_event_get_type (event);
                    const gchar *key;
                    switch (event_type) {
                    case GST_NAVIGATION_EVENT_KEY_PRESS:
                        if (gst_navigation_event_parse_key_event (event, &key)) {
                            if ((strcmp (key, "F11") == 0) || (alt_keypress && strcmp (key, "Return") == 0)) {
                                fullscreen = !(fullscreen);
                                set_fullscreen(renderer_type[type]->gst_window, &fullscreen);
                            } else if (strcmp (key, "Alt_L") == 0) {
                                alt_keypress = true;
                            }
                        }
                        break;
                    case GST_NAVIGATION_EVENT_KEY_RELEASE:
                        if (gst_navigation_event_parse_key_event (event, &key)) {
                            if (strcmp (key, "Alt_L") == 0) {
                                alt_keypress = false;
                            }
                        }
                    default:
                        break;
                    }
                }
                if (event) {
                    gst_event_unref (event);
                }
            }
        }
        break;
#endif
    default:
      /* unhandled message */
        break;
    }
    return TRUE;
}

int video_renderer_choose_codec (bool video_is_h265) {
    video_renderer_t *renderer_used = NULL;
    video_renderer_t *renderer_unused = NULL;
    g_assert(!hls_video);
    if (n_renderers == 1) {
        if (video_is_h265) {
            logger_log(logger, LOGGER_ERR, "video is h265 but the -h265 option was not used");
            return -1;
	}
        renderer_used = renderer_type[0];
    } else {
        renderer_used = video_is_h265 ? renderer_type[1] : renderer_type[0];
        renderer_unused = video_is_h265 ? renderer_type[0] : renderer_type[1];
    }
    if (renderer_used == NULL) { 
        return -1;
    } else if (renderer_used == renderer) {
        return 0;
    } else if (renderer) {
        return -1;
    }
    renderer = renderer_used;
    gst_element_set_state (renderer->pipeline, GST_STATE_PLAYING);
    GstState old_state, new_state;
    if (gst_element_get_state(renderer->pipeline, &old_state, &new_state, 100 * GST_MSECOND) == GST_STATE_CHANGE_FAILURE) {
        g_error("video pipeline failed to go into playing state");
	return -1;
    }
    logger_log(logger, LOGGER_DEBUG, "video_pipeline state change from %s to %s\n",
               gst_element_state_get_name (old_state),gst_element_state_get_name (new_state));
    gst_video_pipeline_base_time = gst_element_get_base_time(renderer->appsrc);
    if (renderer == renderer_type[1]) {
        logger_log(logger, LOGGER_INFO, "*** video format is h265 high definition (HD/4K) video %dx%d", width, height);
    }
    if (renderer_unused) {
        for (int i = 0; i < n_renderers; i++) {
            if (renderer_type[i] != renderer_unused) {
                continue;
            }
            renderer_type[i] = NULL;
            video_renderer_destroy_instance(renderer_unused);
        }
    }
    return 0;
}

unsigned int video_reset_callback(void * loop) {
    if (video_terminate) {
        video_terminate = false;
        if (renderer->appsrc) {
	    gst_app_src_end_of_stream (GST_APP_SRC(renderer->appsrc));
        }
	gboolean flushing = TRUE;
        gst_bus_set_flushing(renderer->bus, flushing);
 	gst_element_set_state (renderer->pipeline, GST_STATE_NULL);
	g_main_loop_quit( (GMainLoop *) loop);
    }
    return (unsigned  int) TRUE;
}

bool video_get_playback_info(double *duration, double *position, float *rate, bool *buffer_empty, bool *buffer_full) {
    gint64 pos = 0;
    GstState state;
    *duration = 0.0;
    *position = -1.0;
    *rate = 0.0f;
    if (!renderer) {
        return true;
    }

    *buffer_empty = (bool) hls_buffer_empty;
    *buffer_full = (bool) hls_buffer_full;
    gst_element_get_state(renderer->pipeline, &state, NULL, 0);
    *rate = 0.0f;
    switch (state) {
    case GST_STATE_PLAYING:
        *rate = 1.0f;
    default:
        break;
    }

    if (!GST_CLOCK_TIME_IS_VALID(hls_duration)) {
        if (!gst_element_query_duration (renderer->pipeline, GST_FORMAT_TIME, &hls_duration)) {
            return true;
        }
    }
    *duration = ((double) hls_duration) / GST_SECOND;
    if (*duration) {
        if (gst_element_query_position (renderer->pipeline, GST_FORMAT_TIME, &pos) &&
                                        GST_CLOCK_TIME_IS_VALID(pos)) {
            *position = ((double) pos) / GST_SECOND;
        }
    }

    logger_log(logger, LOGGER_DEBUG, "********* video_get_playback_info: position %" GST_TIME_FORMAT " duration %" GST_TIME_FORMAT " %s *********",
               GST_TIME_ARGS (pos), GST_TIME_ARGS (hls_duration), gst_element_state_get_name(state));

    return true;
}

void video_renderer_set_start(float position) {
    int pos_in_micros = (int) (position * SECOND_IN_MICROSECS);
    hls_requested_start_position = (gint64) (pos_in_micros * GST_USECOND);
    logger_log(logger, LOGGER_DEBUG, "register HLS video start position %f %lld", position,
               hls_requested_start_position);    
}

void video_renderer_seek(float position) {
    int pos_in_micros = (int) (position * SECOND_IN_MICROSECS);
    gint64 seek_position = (gint64) (pos_in_micros * GST_USECOND);
    /* don't seek to within 1  microsecond  of beginning or end of video */
    if (hls_duration < 2000) return;
    seek_position =  seek_position < 1000 ? 1000 : seek_position;
    seek_position =  seek_position > hls_duration  - 1000 ? hls_duration - 1000 : seek_position;
    g_print("SCRUB: seek to %f secs =  %" GST_TIME_FORMAT ", duration = %" GST_TIME_FORMAT "\n", position,
            GST_TIME_ARGS(seek_position),  GST_TIME_ARGS(hls_duration));
    gboolean result = gst_element_seek_simple(renderer->pipeline, GST_FORMAT_TIME,
                                              (GstSeekFlags)(GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_KEY_UNIT),
                                              seek_position);
    if (result) {
        g_print("seek succeeded\n");
        gst_element_set_state (renderer->pipeline, GST_STATE_PLAYING);	
    } else {
        g_print("seek failed\n");
    }
}

unsigned int video_renderer_listen(void *loop, int id) {
    g_assert(id >= 0 && id < n_renderers);
    return (unsigned int) gst_bus_add_watch(renderer_type[id]->bus,(GstBusFunc)
                                            gstreamer_pipeline_bus_callback, (gpointer) loop);    
}
