/* AirGlass Windows device queue limit. GPL-3.0-or-later. */
#ifndef AIRGLASS_GPU_H
#define AIRGLASS_GPU_H
#ifdef _WIN32
#include <d3d11.h>
#include <dxgi.h>

/* Use the loaded GStreamer runtime, without private window layouts or a newer
 * GStreamer D3D11 SDK dependency. Failure leaves normal presentation active. */
static gboolean airglass_limit_gpu_queue(gpointer gst_device, guint *previous) {
    typedef ID3D11Device *(*get_device_fn)(gpointer);
    HMODULE runtime = GetModuleHandleA("libgstd3d11-1.0-0.dll");
    get_device_fn get_device = runtime ? (get_device_fn) GetProcAddress(runtime,
                              "gst_d3d11_device_get_device_handle") : NULL;
    if (!get_device) return FALSE;
    ID3D11Device *device = get_device(gst_device);
    IDXGIDevice1 *dxgi = NULL;
    if (!device || FAILED(device->lpVtbl->QueryInterface(device, &IID_IDXGIDevice1,
                                                      (void **) &dxgi))) return FALSE;
    UINT old_limit = 0, checked = 0;
    dxgi->lpVtbl->GetMaximumFrameLatency(dxgi, &old_limit);
    HRESULT result = dxgi->lpVtbl->SetMaximumFrameLatency(dxgi, 1);
    if (SUCCEEDED(result)) result = dxgi->lpVtbl->GetMaximumFrameLatency(dxgi, &checked);
    dxgi->lpVtbl->Release(dxgi);
    if (previous) *previous = old_limit;
    return SUCCEEDED(result) && checked == 1;
}
#endif
#endif
