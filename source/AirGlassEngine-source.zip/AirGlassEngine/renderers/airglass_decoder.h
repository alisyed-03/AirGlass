/* AirGlass per-process hardware decoder preferences. GPL-3.0-or-later. */
#ifndef AIRGLASS_DECODER_H
#define AIRGLASS_DECODER_H
static gboolean airglass_rank_decoder(const gchar *name, gboolean nvidia, guint rank, logger_t *log) {
    GstElementFactory *factory = gst_element_factory_find(name);
    if (!factory) return FALSE;
    /* Loading refreshes cached metadata against this machine's driver and
     * per-codec device capabilities. A GPU's brand alone is not sufficient. */
    GstPluginFeature *loaded = gst_plugin_feature_load(GST_PLUGIN_FEATURE(factory));
    gboolean ready = loaded != NULL;
#ifdef _WIN32
    if (ready && nvidia) {
        typedef gboolean (*load_nvrtc_fn)(void);
        HMODULE cuda = GetModuleHandleA("libgstcuda-1.0-0.dll");
        load_nvrtc_fn load_nvrtc = cuda ? (load_nvrtc_fn) GetProcAddress(cuda, "gst_cuda_nvrtc_load_library") : NULL;
        ready = load_nvrtc && load_nvrtc();
    }
#endif
    if (ready) {
        GstElement *probe = gst_element_factory_create(GST_ELEMENT_FACTORY(loaded), NULL);
        ready = probe && gst_element_set_state(probe, GST_STATE_READY) != GST_STATE_CHANGE_FAILURE;
        if (probe) { gst_element_set_state(probe, GST_STATE_NULL); gst_object_unref(probe); }
    }
    gst_plugin_feature_set_rank(loaded ? loaded : GST_PLUGIN_FEATURE(factory), ready ? rank : GST_RANK_NONE);
    if (loaded) gst_object_unref(loaded);
    gst_object_unref(factory);
    if (!ready) logger_log(log, LOGGER_WARNING, "AirGlass preferred decoder runtime unavailable: %s; automatic fallback active", name);
    return ready;
}
static void airglass_prefer_decoders(const gchar *preference, logger_t *log) {
    const gchar *nv[] = {"nvh264dec", "nvh265dec"};
    const gchar *dx[] = {"d3d11h264dec", "d3d11h265dec"};
    gboolean nvidia = g_strcmp0(preference, "Nvidia") == 0;
    gboolean automatic = !preference || g_strcmp0(preference, "Auto") == 0;
    gboolean direct3d = g_strcmp0(preference, "Direct3D11") == 0;
    if (automatic || nvidia || direct3d) {
        /* Re-evaluate the current driver even if a cache was made on an older
         * GPU. Capability factories are registered by the loaded plugins. */
        const gchar *plugins[] = {"d3d11", "nvcodec"};
        for (guint i=0;i<(automatic || nvidia ? 2u : 1u);i++) {
            GstPlugin *plugin=gst_plugin_load_by_name(plugins[i]);
            if (plugin) gst_object_unref(plugin);
        }
    }
    if (automatic) {
        const gchar *sw[] = {"avdec_h264", "avdec_h265"};
        for (guint i = 0; i < 2; i++) {
            gboolean cpu = airglass_rank_decoder(sw[i], FALSE, GST_RANK_PRIMARY + 64, log);
            /* Native D3D11 surfaces avoid the CUDA/I420 conversion required by
             * this nvcodec runtime. On NVIDIA this still uses the GPU decoder. */
            gboolean dx_ready = airglass_rank_decoder(dx[i], FALSE, GST_RANK_PRIMARY + 256, log);
            gboolean nv_ready = airglass_rank_decoder(nv[i], TRUE, GST_RANK_PRIMARY + 128, log);
            const gchar *selected = dx_ready ? dx[i] : nv_ready ? nv[i] : cpu ? sw[i] : "none";
            logger_log(log, LOGGER_INFO, "AirGlass automatic decoder: %s -> %s (NVIDIA %s; Direct3D11 %s; software %s)",
                       i ? "HEVC" : "H264", selected, nv_ready ? "available" : "unavailable",
                       dx_ready ? "available" : "unavailable", cpu ? "available" : "unavailable");
        }
        return;
    }
    if (!nvidia && !direct3d) return;
    if (direct3d) {
        for (guint i=0;i<2;i++) {
            GstElementFactory *factory=gst_element_factory_find(nv[i]);
            if(factory) {gst_plugin_feature_set_rank(GST_PLUGIN_FEATURE(factory),GST_RANK_NONE);gst_object_unref(factory);}
        }
        logger_log(log,LOGGER_INFO,"AirGlass Direct3D11: NVIDIA plugin is opt-in; CPU fallback retained");
    }
    for (guint i = 0; i < 2; i++) {
        const gchar *name = nvidia ? nv[i] : dx[i];
        if (airglass_rank_decoder(name, nvidia, GST_RANK_PRIMARY + 256, log))
            logger_log(log, LOGGER_INFO, "AirGlass preferred decoder: %s (automatic fallback available)", name);
        else logger_log(log, LOGGER_WARNING, "AirGlass preferred decoder unavailable: %s; automatic fallback active", name);
    }
}
#endif
