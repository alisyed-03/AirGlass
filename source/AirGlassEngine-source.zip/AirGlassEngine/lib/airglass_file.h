/* UTF-8 filesystem paths for Windows user profiles. GPL-3.0-or-later. */
#ifndef AIRGLASS_FILE_H
#define AIRGLASS_FILE_H
#include <stdio.h>
#ifdef _WIN32
#include <windows.h>
#include <stdlib.h>
#include <io.h>
static wchar_t *airglass_wide_path(const char *path) {
    int count=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,path,-1,NULL,0);
    if (!count) return NULL;
    wchar_t *wide=(wchar_t *)malloc(count*sizeof(wchar_t));
    if (wide) MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,path,-1,wide,count);
    return wide;
}
static FILE *airglass_fopen(const char *path,const char *mode) {
    wchar_t *wide=airglass_wide_path(path), *wmode=airglass_wide_path(mode);
    FILE *file=wide && wmode ? _wfopen(wide,wmode) : NULL;
    free(wide); free(wmode); return file;
}
static int airglass_access(const char *path,int mode) {
    wchar_t *wide=airglass_wide_path(path);
    int result=wide ? _waccess(wide,mode) : -1;free(wide);return result;
}
static int airglass_remove(const char *path) {
    wchar_t *wide=airglass_wide_path(path);
    int result=wide ? _wremove(wide) : -1;free(wide);return result;
}
#else
#define airglass_fopen fopen
#endif
#endif
