/* AirGlass: per-connection Windows streaming options; no registry changes. */
#ifndef AIRGLASS_SOCKET_H
#define AIRGLASS_SOCKET_H
#ifdef _WIN32
#include <winsock2.h>
#include <mstcpip.h>
#ifndef SIO_TCP_SET_ACK_FREQUENCY
#define SIO_TCP_SET_ACK_FREQUENCY _WSAIOW(IOC_VENDOR, 23)
#endif
static int airglass_fast_ack(SOCKET socket) {
    DWORD frequency = 1, bytes = 0;
    return WSAIoctl(socket, SIO_TCP_SET_ACK_FREQUENCY,
                    &frequency, sizeof(frequency), NULL, 0, &bytes, NULL, NULL);
}
#endif
#endif
