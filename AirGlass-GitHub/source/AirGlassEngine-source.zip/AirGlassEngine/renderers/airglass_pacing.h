/* AirGlass adaptive capture-timestamp pacing. GPL-3.0-or-later. */
#ifndef AIRGLASS_PACING_H
#define AIRGLASS_PACING_H
#include <gst/gst.h>
#include <stdlib.h>
#define AIRGLASS_JITTER_SAMPLES 64

typedef struct {
    gboolean valid;
    guint64 capture_origin, arrival_origin, last_capture, last_arrival;
    guint64 current_budget, jitter, resets;
    gint64 transit[AIRGLASS_JITTER_SAMPLES];
    guint count, next;
} airglass_pacing_t;

static int airglass_compare_transit(const void *a, const void *b) {
    gint64 left = *(const gint64 *) a, right = *(const gint64 *) b;
    return (left > right) - (left < right);
}

/* 'now' is decoded-frame availability, not encoded-packet arrival. Scheduling
 * before decode can make every frame late when the decoder needs to reorder.
 * Recent transit variation chooses the cushion; the selected frame period is
 * a ceiling, not an unconditional extra frame of delay. */
static inline guint64 airglass_presentation_time(airglass_pacing_t *p,
                                                guint64 capture, guint64 now,
                                                guint64 ceiling) {
    gboolean reset = !p->valid || capture < p->last_capture || now < p->last_arrival;
    if (!reset) {
        gint64 change = (gint64) (now - p->last_arrival) -
                        (gint64) (capture - p->last_capture);
        gint64 limit = (gint64) MAX(4 * ceiling, 250 * GST_MSECOND);
        reset = change > limit || change < -limit;
    }
    if (reset) {
        p->valid = TRUE;
        p->capture_origin = capture;
        p->arrival_origin = now;
        p->current_budget = MIN(8 * GST_MSECOND, ceiling);
        p->count = p->next = 0;
        p->resets++;
    }
    guint64 elapsed = reset ? 0 : now - p->last_arrival;
    gint64 transit = (gint64) (now - p->arrival_origin) -
                     (gint64) (capture - p->capture_origin);
    p->transit[p->next++ % AIRGLASS_JITTER_SAMPLES] = transit;
    p->count = MIN(p->count + 1, AIRGLASS_JITTER_SAMPLES);
    gint64 ordered[AIRGLASS_JITTER_SAMPLES];
    for (guint i = 0; i < p->count; i++) ordered[i] = p->transit[i];
    qsort(ordered, p->count, sizeof(gint64), airglass_compare_transit);
    guint percentile = (p->count * 95 + 99) / 100 - 1;
    p->jitter = ordered[percentile] - ordered[0];
    guint64 desired = MIN(ceiling, MAX(4 * GST_MSECOND, p->jitter + 2 * GST_MSECOND));
    if (desired > p->current_budget) p->current_budget = desired;
    else p->current_budget -= MIN(p->current_budget - desired, elapsed / 1000);
    gint64 target = (gint64) p->arrival_origin + (gint64) (capture - p->capture_origin) +
                    ordered[0] + (gint64) p->current_budget;
    p->last_capture = capture;
    p->last_arrival = now;
    return target > 0 ? (guint64) target : 0;
}
#endif
