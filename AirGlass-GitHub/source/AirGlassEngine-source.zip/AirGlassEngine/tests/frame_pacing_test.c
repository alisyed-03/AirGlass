/* AirGlass real GStreamer sink pacing checks. GPL-3.0-or-later. */
#include <gst/gst.h>
#include <gst/app/gstappsrc.h>
#include "airglass_pacing.h"
#include <math.h>
#include <stdio.h>
#ifdef _WIN32
#include <windows.h>
#include <mmsystem.h>
#endif

typedef struct { guint count; guint64 times[64], sequences[64]; } samples_t;
static void handoff(GstElement *sink, GstBuffer *buffer, GstPad *pad, gpointer data) {
    samples_t *s = data;
    if (s->count < 64) {
        s->times[s->count] = gst_util_get_timestamp();
        s->sequences[s->count++] = GST_BUFFER_OFFSET(buffer);
    }
}
static double run_stream(guint fps, gboolean paced) {
    GError *error = NULL;
    guint64 period = GST_SECOND / fps;
    gchar *description = g_strdup_printf(
        "appsrc name=source is-live=true format=time block=true max-buffers=2 max-bytes=0 ! "
        /* Isolate timestamp scheduling here. The separate backlog check covers
         * decoded-frame dropping; do not conflate drops with clock jitter. */
        "queue max-size-buffers=1 max-size-bytes=0 max-size-time=0 ! "
        "fakesink name=sink signal-handoffs=true sync=%s async=false processing-deadline=0 max-lateness=-1",
        paced ? "true" : "false");
    GstElement *pipeline = gst_parse_launch(description, &error);
    g_free(description);
    if (error || !pipeline) g_error("Pipeline: %s", error ? error->message : "null");
    GstElement *source = gst_bin_get_by_name(GST_BIN(pipeline), "source");
    GstElement *sink = gst_bin_get_by_name(GST_BIN(pipeline), "sink");
    GstCaps *caps = gst_caps_new_simple("video/x-raw", "format", G_TYPE_STRING, "RGBA",
        "width", G_TYPE_INT, 1, "height", G_TYPE_INT, 1,
        "framerate", GST_TYPE_FRACTION, fps, 1, NULL);
    g_object_set(source, "caps", caps, NULL); gst_caps_unref(caps);
    samples_t samples = {0};
    g_signal_connect(sink, "handoff", G_CALLBACK(handoff), &samples);
    gst_element_set_state(pipeline, GST_STATE_PLAYING);
    gst_element_get_state(pipeline, NULL, NULL, GST_SECOND);
    GstClock *clock = gst_system_clock_obtain();
    guint64 begin = gst_util_get_timestamp();
    airglass_pacing_t pacing = {0};
    for (guint i = 0; i < 24; i++) {
        gint64 wobble = i == 0 ? 0 : (i % 2 ? (gint64) period * 3 / 10 : -(gint64) period * 3 / 10);
        guint64 arrival = begin + i * period + wobble;
        guint64 current = gst_util_get_timestamp();
        if (arrival > current) {
            GstClockID wait = gst_clock_new_single_shot_id(clock, arrival);
            gst_clock_id_wait(wait, NULL); gst_clock_id_unref(wait);
        }
        GstBuffer *buffer = gst_buffer_new_allocate(NULL, 4, NULL);
        guint64 now = gst_element_get_current_running_time(pipeline);
        GST_BUFFER_PTS(buffer) = paced ? airglass_presentation_time(&pacing, 100 * GST_SECOND + i * period, now, period) : now;
        GST_BUFFER_DURATION(buffer) = period;
        GST_BUFFER_OFFSET(buffer) = i;
        if (gst_app_src_push_buffer(GST_APP_SRC(source), buffer) != GST_FLOW_OK) g_error("push failed");
    }
    gst_app_src_end_of_stream(GST_APP_SRC(source));
    GstBus *bus = gst_element_get_bus(pipeline);
    GstMessage *message = gst_bus_timed_pop_filtered(bus, 3 * GST_SECOND, GST_MESSAGE_EOS | GST_MESSAGE_ERROR);
    if (!message || GST_MESSAGE_TYPE(message) != GST_MESSAGE_EOS) g_error("Stream failed or timed out");
    gst_message_unref(message); gst_object_unref(bus);
    gst_element_set_state(pipeline, GST_STATE_NULL);
    gst_element_get_state(pipeline, NULL, NULL, GST_SECOND);
    if (samples.count != 24) g_error("Expected all 24 frames, received %u", samples.count);
    double total_error = 0;
    for (guint i = 1; i < samples.count; i++)
        total_error += fabs((double) (samples.times[i] - samples.times[i-1]) -
                            period * (samples.sequences[i] - samples.sequences[i-1]));
    double mean_error = total_error / (samples.count - 1) / GST_MSECOND;
    printf("%u fps %s: frames=%u mean interval error=%.3f ms\n", fps, paced ? "paced" : "immediate", samples.count, mean_error);
    gst_object_unref(clock); gst_object_unref(source); gst_object_unref(sink); gst_object_unref(pipeline);
    return mean_error;
}
int main(int argc, char **argv) {
    setvbuf(stdout, NULL, _IONBF, 0);
#ifdef _WIN32
    /* Keep the synthetic producer's timers precise enough to create the
     * intended arrival pattern. This is a test-process-only timer request. */
    timeBeginPeriod(1);
#endif
    gst_init(&argc, &argv);
    for (guint fps = 15; fps <= 60; fps *= 2) {
        guint64 period = GST_SECOND / fps;
        airglass_pacing_t p = {0};
        guint64 pts = 0, now = 0, capture = 0;
        for (guint i = 0; i < 400; i++) {
            capture = 100 * GST_SECOND + i * period;
            now = GST_SECOND + i * period;
            pts = airglass_presentation_time(&p, capture, now, period);
            if (pts < now || pts > now + period) g_error("Clean-stream budget invalid");
        }
        if (p.current_budget != 4 * GST_MSECOND) g_error("Clean stream did not shed unnecessary pacing delay");
        printf("PASS: %u fps clean-link pacing settles to 4 ms; old fixed budget %.2f ms\n", fps, period / (double) GST_MSECOND);
        guint64 previous_resets = p.resets;
        pts = airglass_presentation_time(&p, capture + period, now + GST_SECOND, period);
        if (p.resets != previous_resets + 1 || pts != now + GST_SECOND + 8 * GST_MSECOND) g_error("Long-stall recovery failed");
        previous_resets = p.resets;
        pts = airglass_presentation_time(&p, 50 * GST_SECOND, now + GST_SECOND + period, period);
        if (p.resets != previous_resets + 1) g_error("Backward capture clock recovery failed");
        memset(&p, 0, sizeof(p));
        for (guint i = 0; i < 400; i++) {
            gint64 wobble = i % 2 ? period * 3 / 10 : 0;
            now = GST_SECOND + i * period + wobble;
            pts = airglass_presentation_time(&p, 100 * GST_SECOND + i * period, now, period);
            if (pts > now + period) g_error("Adaptive cushion exceeded ceiling");
        }
        if (p.current_budget < period * 3 / 10) g_error("Adaptive cushion did not grow with variation");
        memset(&p, 0, sizeof(p));
        for (guint i = 0; i < 3600; i++) {
            guint64 elapsed = i * period;
            airglass_presentation_time(&p, 100 * GST_SECOND + elapsed + elapsed / 5000,
                                      GST_SECOND + elapsed, period);
        }
        if (p.resets != 1) g_error("Normal clock drift caused disruptive resets");
        printf("PASS: %u fps variation growth, budget ceiling, stall recovery and 200 ppm clock drift\n", fps);
        double immediate = run_stream(fps, FALSE);
        double paced = run_stream(fps, TRUE);
        if (paced > immediate * 0.5) g_error("Pacing failed to reduce synthetic arrival jitter at %u fps", fps);
        printf("PASS: %u fps real sink reduces controlled arrival jitter\n", fps);
    }
#ifdef _WIN32
    timeEndPeriod(1);
#endif
    return 0;
}
